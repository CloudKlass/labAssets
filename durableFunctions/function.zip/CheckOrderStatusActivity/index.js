module.exports = async function (context) {
  const orderId = context.bindings.input;
  const url = process.env.ORDER_STATUS_FUNCTION_URL;
  if (!url) throw new Error("Missing ORDER_STATUS_FUNCTION_URL app setting.");
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ orderId }) });
  if (!r.ok) { context.log(`Order status API returned ${r.status}`); return { orderId, status: "Unknown", expectedDelivery: null }; }
  return await r.json();
};
