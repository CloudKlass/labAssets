module.exports = async function (context) {
  const { caseId, request, classification, orderInfo, summary } = context.bindings.input || {};
  if (!caseId) throw new Error("Missing caseId in PersistFinalCaseActivity input.");
  context.bindings.outputDocument = {
    id: caseId,
    caseId,
    orderId: request?.orderId || null,
    customerEmail: request?.customerEmail || null,
    rawComplaint: request?.complaintText || null,
    issueType: classification?.issueType || null,
    severity: classification?.severity || null,
    orderStatus: orderInfo?.status || null,
    expectedDelivery: orderInfo?.expectedDelivery || null,
    llmSummaryForAgent: summary || null,
    issueEmbedding: null,
    createdUtc: new Date().toISOString()
  };
  return { caseId, status: "Saved" };
};
