module.exports = async function (context) {
  const inp = context.bindings.input || {};
  const { request = {}, classification = {}, orderInfo = {} } = inp;
  const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
  const key = process.env.AZURE_OPENAI_KEY;
  const dep = process.env.AZURE_OPENAI_DEPLOYMENT;
  if (!endpoint || !key || !dep) throw new Error("Missing AZURE_OPENAI_* app settings.");
  const url = `${endpoint.replace(/\/$/, "")}/openai/deployments/${dep}/chat/completions?api-version=2024-10-21`;

  const prompt = `
Customer complaint: ${request.complaintText || ""}
Order status: ${orderInfo.status || "Unknown"}, expected delivery ${orderInfo.expectedDelivery || "N/A"}
Issue type: ${classification.issueType || "Unclassified"}, severity: ${classification.severity || "Unknown"}
Write a concise 2–3 sentence summary for a human support agent and include order ${request.orderId || ""}.`;

  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", "api-key": key },
    body: JSON.stringify({ messages: [
      { role: "system", content: "You summarize cases succinctly." },
      { role: "user", content: prompt }
    ]})
  });
  if (!r.ok) { const t = await r.text(); throw new Error(`OpenAI summarize failed ${r.status}: ${t}`); }
  const data = await r.json();
  const content = data?.choices?.[0]?.message?.content;
  if (!content) throw new Error("No content from OpenAI summarize.");
  return content;
};
