module.exports = async function (context) {
  const req = context.bindings.input || {};
  const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
  const key = process.env.AZURE_OPENAI_KEY;
  const dep = process.env.AZURE_OPENAI_DEPLOYMENT;
  if (!endpoint || !key || !dep) throw new Error("Missing AZURE_OPENAI_* app settings.");

  const url = `${endpoint.replace(/\/$/, "")}/openai/deployments/${dep}/chat/completions?api-version=2024-10-21`;
  const payload = {
    messages: [
      { role: "system", content: "Classify e-commerce issues. Respond strict JSON: {\"issueType\":\"...\",\"severity\":\"Low|Medium|High\"}." },
      { role: "user", content: `Order ${req.orderId || ""}\nComplaint: ${req.complaintText || ""}` }
    ],
    response_format: { type: "json_object" }
  };
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json", "api-key": key }, body: JSON.stringify(payload) });
  if (!r.ok) { const t = await r.text(); throw new Error(`OpenAI classify failed ${r.status}: ${t}`); }
  const data = await r.json();
  const content = data?.choices?.[0]?.message?.content;
  if (!content) throw new Error("No content from OpenAI classify.");
  try { return JSON.parse(content); } catch (e) { throw new Error("Failed to parse classification JSON: " + content); }
};
