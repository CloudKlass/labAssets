module.exports = async function (context) {
  const req = context.bindings.input || {};
  const idPart = Math.random().toString(36).slice(2, 8).toUpperCase();
  const d = new Date().toISOString().slice(0,10);
  const caseId = `CASE-${d}-${idPart}`;
  context.log(`Generated caseId: ${caseId} for order ${req.orderId || "unknown"}`);
  return caseId;
};
